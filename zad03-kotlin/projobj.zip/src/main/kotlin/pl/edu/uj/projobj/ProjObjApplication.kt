package pl.edu.uj.projobj

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class ProjObjApplication

fun main(args: Array<String>) {
	runApplication<ProjObjApplication>(*args)
}
